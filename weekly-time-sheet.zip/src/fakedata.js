export const data = {
    "Mark O'Brien": {
      "Boosted CRM Test - PHP Developer": {
        "07/18/2021": 13.0,
        "Project Type": "Hourly",
        "Company Name": "Boosted CRM Test",
        "Active": "Active",
        "07/25/2021": 27.0
      },
      "Boosted CRM Test - PHP Developer Another Test": {
        "07/25/2021": 120.0,
        "Project Type": "Hourly",
        "Company Name": "Boosted CRM Test",
        "Active": "Active",
        "08/01/2021": 220.0
      }
    },
    "Jennifer O'Brien": {
      "Test boosted CRM Mark 1000": {
        "07/25/2021": 211.0,
        "Project Type": "Hourly",
        "Company Name": "Boosted CRM Test",
        "Active": "Not Active",
        "07/18/2021": 100.0,
        "08/01/2021": 300.0
      },
      "Test boosted CRM Mark": {
        "07/25/2021": 211.0,
        "Project Type": "Hourly",
        "Company Name": "Boosted CRM Test",
        "Active": "Not Active",
        "07/18/2021": 100.0,
        "08/01/2021": 300.0
      },
      "Test boosted  Mark": {
        "07/25/2021": 211.0,
        "Project Type": "Hourly",
        "Company Name": "Boosted CRM Test",
        "Active": "Not Active",
        "07/18/2021": 100.0,
        "08/01/2021": 300.0
      },
      
    }
  }