import React from 'react';
import TabsData from './TabsData';


const App = () => {
  return (
    <div>
        <TabsData/>
    </div>
  );
};

export default App;